<?php

namespace Novosga\Controller;

/**
 * Class pai dos controladores internos do sistema.
 *
 * @author eco
 */
abstract class InternalController extends AppController
{
}
