<?php

namespace Novosga\Http;

/**
 * Response Wrapper.
 *
 * @author Rogerio Lino <rogeriolino@gmail.com>
 */
class Response extends \Slim\Http\Response
{
}
