<?php
return array(
    "driver" => "pdo_mysql",
    "host" => "127.0.0.1",
    "port" => "3306",
    "user" => "root",
    "password" => "123456",
    "dbname" => "sgatjdft",
    "charset" => "utf8",
);
